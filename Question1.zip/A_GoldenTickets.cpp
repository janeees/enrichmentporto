#include <stdio.h>
#include <string.h>

int main(){

    int n; // number of participating teams
    int m; // number of top teams
    int k; // number of top teams that are not in the top m teams

    scanf("%d %d %d", &n, &m, &k); getchar();

    char exclude_institution[n+10][110];
    int count_exclude = 0;
    int count = 0;

    char saved_team[n+10][110];
    int count_saved = 0;

    for(int i = 0; i < n; i++){

        char team[110] = {};
        char institution[110] = {};
        int excluded = 0;

        scanf("%s %s", team, institution); getchar();

        if(i < m){

            strcpy(exclude_institution[count_exclude++], institution);

        }

        for(int j = 0; j < count_exclude; j++){

            if(!strcmp(institution, exclude_institution[j])){

                excluded = 1;

            }

        }

        if(!excluded && count < k){

            strcpy(saved_team[count_saved++], team);
            strcpy(exclude_institution[count_exclude++], institution);
            count++;


        }

    }

    printf("%d\n", count_saved);

    for(int i = 0; i < count_saved; i++){

        printf("%s\n", saved_team[i]);

    }

}

/*

3 1 2
ARUA UOGX
NOIHS UHOLO
IKUBUF UHOLO

*/