#include <stdio.h>

int main(){

    int t, n;
    scanf("%d", &t);
    long long d, low, high, count, mid, res, curr, cost[10005];

    for(int z = 0; z < t; z++){

        low = 0, high = 1e18;

        scanf("%d %lld", &n, &d);

        for(int i = 0; i < n; i++){

            scanf("%lld", &cost[i]);

        }

        while(low < high){

            mid = low + (high - low) / 2;
            count = 0;

            for(int i = 0; i < n; i++){

                count += (mid / cost[i] + 1) / 2;
                if(count >= d) break;

            }

            if(count >= d) high = mid;
            else low = mid + 1;

        }

        res = 0, count = 0;

        for(int i = 0; i < n; i++){

            curr = (high / cost[i] + 1) / 2;
            res += curr * curr * cost[i];
            count += curr;

        }

        res -= (count - d) * high;

        printf("%lld\n", res);

    }

}