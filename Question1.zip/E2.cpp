#include <stdio.h>
#include <string.h>

int main() {
	
    long int N; //length
    char S[10000];
    int Q; //jumlah string
    
    scanf("%ld", &N); getchar();
    scanf("%s", S); getchar();
    scanf("%d", &Q); getchar();
    
    for (int i = 0; i < Q; i++) 
	{
    	
        char S2[10000];
        
        scanf("%s", S2); getchar();
        
        int idx = N;
        int j = 0;
       	
		for (int k = N - 1; k >= 0; k--) 
		{
        	if (strncmp(S2+k, S+j, idx-k) == 0) 
			{
           		j += idx - k;
            	idx = k;
        	}
		}
		
	    if (j == N) 
		{
	        printf("YES\n");
	    }
	    
		else 
		{
	        printf("NO\n");
	    }
	}


}

/*

	R EVESE

*/


//7
//REVERSE
//5
//SEVERER
//EVERSER
//REVERSE
//EVEREST
//RESERVE

