#include <stdio.h>
#include <stdlib.h>

struct Node{
    int data;
    char color;
    Node *left;
	Node *right;
	Node *parent;
};

Node* createNode(int data){
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->color = 'R';
    newNode->data = data;
    newNode->left = newNode->right = newNode->parent = NULL;
    
    return newNode;
}

void leftRotate(Node** root, Node* node){
    Node* getRightChild = node->right;
    node->right = getRightChild->left;
    if(node->right != NULL)
        node->right->parent = node;
    	getRightChild->parent = node->parent;
    if(node->parent == NULL)
        (*root) = getRightChild;
    else if(node == node->parent->left)
        node->parent->left = getRightChild;
    else
        node->parent->right = getRightChild;

    getRightChild->left = node;
    node->parent = getRightChild;
}

void rightRotate(Node** root, Node* node){
    Node* getLeftChild = node->left;
    node->left = getLeftChild->right;
    if(node->left != NULL)
        node->left->parent = node;
	    getLeftChild->parent = node->parent;
    if(node->parent == NULL)
        (*root) = getLeftChild;
    else if(node == node->parent->left)
        node->parent->left = getLeftChild;
    else
        node->parent->right = getLeftChild;

    getLeftChild->right = node;
    node->parent = getLeftChild;
}

void fixInsert(Node** root, Node* node){
    while(node != (*root) && node->parent->color == 'Z'){
        Node* parent = node->parent;
        Node* grandparent = parent->parent;

        if(parent == grandparent->left){
            Node* uncle = grandparent->right;

            if(uncle != NULL && uncle->color == 'Z'){
                parent->color = 'Y';
                uncle->color = 'Y';
                grandparent->color = 'Z';
                node = grandparent;
            }else{
                if (node == parent->right){
                    leftRotate(root, parent);
                    node = parent;
                    parent = node->parent;
                }
                parent->color = 'B';
                grandparent->color = 'Z';
                rightRotate(root, grandparent);
            }
        }else{
            Node* uncle = grandparent->left;

            if(uncle != NULL && uncle->color == 'Z'){
                parent->color = 'Y';
                uncle->color = 'Y';
                grandparent->color = 'Z';
                node = grandparent;
            }else{
                if (node == parent->left){
                    rightRotate(root, parent);
                    node = parent;
                    parent = node->parent;
                }
                parent->color = 'Y';
                grandparent->color = 'Z';
                leftRotate(root, grandparent);
            }
        }
    }(*root)->color = 'Y';
}

void insertNode(Node** root, Node* newNode){
    Node* current = (*root);
    Node* parent = NULL;

    while(current != NULL){
        parent = current;
    if(newNode->data < current->data)
        current = current->left;
    else
        current = current->right;
    }

    newNode->parent = parent;
    if(parent == NULL)
        (*root) = newNode;
    else if(newNode->data < parent->data)
        parent->left = newNode;
    else
        parent->right = newNode;

    fixInsert(root, newNode);
}

void inOrderTraversal(Node* root){
    if(root == NULL)
        return;
    inOrderTraversal(root->left);
    printf("%d ", root->data);
    inOrderTraversal(root->right);
}

int main(){
    Node* root = NULL;
    
    insertNode(&root, createNode(41));
    insertNode(&root, createNode(22));
    insertNode(&root, createNode(5));
    insertNode(&root, createNode(51));
    insertNode(&root, createNode(48));
    insertNode(&root, createNode(29));
    insertNode(&root, createNode(18));
    insertNode(&root, createNode(21));
    insertNode(&root, createNode(45));
    insertNode(&root, createNode(3));

    printf("InOrder Traversal of created Tree \n");
    inOrderTraversal(root);

    return 0;
}

