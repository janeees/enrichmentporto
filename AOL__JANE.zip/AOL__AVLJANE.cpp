#include <stdio.h>
#include <stdlib.h>

struct Node{
    int data;
	int height;
    struct Node* left;
    struct Node* right;
};

int height(struct Node* node){
    if (node == NULL)
        return 0;
    return node->height;
}

int Balance(struct Node* node){
    if (node == NULL)
        return 0;
    return height(node->left) - height(node->right);
}

int max(int a, int b){
    return (a > b) ? a : b;
}

struct Node* newNode(int data){
    struct Node* node = (struct Node*)malloc(sizeof(struct Node));
    node->data = data;
    node->height = 1;
    node->left = node->right = NULL;
    return node;
}

struct Node* rightRotate(struct Node* y){
    struct Node* x = y->left;
    struct Node* T2 = x->right;

    x->right = y;
    y->left = T2;

    y->height = max(height(y->left), height(y->right)) + 1;
    x->height = max(height(x->left), height(x->right)) + 1;

    return x;
}

struct Node* leftRotate(struct Node* y){
    struct Node* x = y->right;
    struct Node* T2 = x->left;

    x->left = y;
    y->right = T2;

    y->height = max(height(y->right), height(y->left)) + 1;
    x->height = max(height(x->right), height(x->left)) + 1;

    return x;
}

struct Node* insert(struct Node* node, Node* newNode){
    if (node == NULL) return newNode;

    if (newNode->data < node->data)
        node->left = insert(node->left, newNode);
    else if (newNode->data > node->data)
        node->right = insert(node->right, newNode);
    else
        return node;

    node->height = 1 + max(height(node->left), height(node->right));

    int balance = getBalance(Node);

    if (balance > 1 && getBalance(node->left) >= 0)
        return rightRotate(node);
    else if (balance > 1 && getBalance(node->left) < 0) {
        node->left = leftRotate(node->left);
        return rightRotate(node);
    }
    else if (balance < -1 && getBalance(node->right) <= 0)
        return leftRotate(node);
    else if (balance < -1 && getBalance(node->right) > 0) {
        node->right = rightRotate(node->right);
        return leftRotate(node);
    }

    return node;
}

struct Node* minValueNode(struct Node* node){
    struct Node* current = node;
    while (current->left != NULL)
        current = current->left;
    return current;
}

struct Node* deleteNode(struct Node* root, int data){
    if(root == NULL)
        return root;

    if(data < root->data)
        root->left = deleteNode(root->left, data);
    else if(data > root->data)
        root->right = deleteNode(root->right, data);
    else{
        if((root->left == NULL) || (root->right == NULL)){
            struct Node* temp = root->left ? root->left : root->right;
            if(temp == NULL){
                temp = root;
                root = NULL;
            }else
                *root = *temp;
            free(temp);
        }else{
            struct Node* temp = minValueNode(root->right);
            root->data = temp->data;
            root->right = deleteNode(root->right, temp->data);
        }
    }if(root == NULL) return root;
    root->height = 1 + max(height(root->left), height(root->right));
    int balance = getBalance(root);
    if(balance > 1 && getBalance(root->left) >= 0)
        return rightRotate(root);
    if(balance > 1 && getBalance(root->left) < 0){
        root->left = leftRotate(root->left);
        return rightRotate(root);
    }if(balance < -1 && getBalance(root->right) <= 0)
        return leftRotate(root);
    if(balance < -1 && getBalance(root->right) > 0){
        root->right = rightRotate(root->right);
        return leftRotate(root);
    }
    return root;
}

struct Node* search(struct Node* root, int data){
    if (root == NULL || root->data == data)
        return root;
    if (data < root->data)
        return search(root->left, data);
    return search(root->right, data);
}

void inorderTraversal(struct Node* root){
    if (root != NULL) {
        inorderTraversal(root->left);
        printf("%d ", root->data);
        inorderTraversal(root->right);
    }
}

void preorderTraversal(struct Node* root){
    if (root != NULL) {
        printf("%d ", root->data);
        preorderTraversal(root->left);
        preorderTraversal(root->right);
    }
}

void postorderTraversal(struct Node* root){
    if (root != NULL) {
        postorderTraversal(root->left);
        postorderTraversal(root->right);
        printf("%d ", root->data);
    }
}

void freeTree(struct Node* root){
    if (root != NULL) {
        freeTree(root->left);
        freeTree(root->right);
        free(root);
    }
}

int main(){
  struct Node* root = NULL;
	int pick, value;
	root = insert(root, newNode(19));
  root = insert(root, newNode(11));
  root = insert(root, newNode(6));
  root = insert(root, newNode(14));
  root = insert(root, newNode(36));
  root = insert(root, newNode(27));
  root = insert(root, newNode(75));
  root = insert(root, newNode(63));
  root = insert(root, newNode(81));
  do {
    printf("1. Insertion\n");
		printf("2. Deletion\n");
		printf("3. Traversal\n");
		printf("4. Exit\n");
		printf("Choose: ");
        scanf("%d", &pick);

        switch (pick) {
            case 1:
                printf("Insert: ");
                scanf("%d", &value);
                root = insert(root, newNode(value));
                
                system("pause");
                system("cls");
                break;
                
            case 2:
                printf("Delete: ");
                scanf("%d", &value);
                if (search(root, value) == NULL) {
                    printf("Data not found\n");
                } else {
                    root = deleteNode(root, value);
                    printf("Data found\n");
                    printf("Value %d was deleted.\n", value);
                }
                
                system("pause");
                system("cls");
                break;
                
            case 3:
                printf("Preorder Traversal: ");
                preorderTraversal(root);
                printf("\nInorder Traversal: ");
                inorderTraversal(root);
                printf("\nPostorder Traversal: ");
                postorderTraversal(root);
                printf("\n");
                
                system("pause");
                system("cls");
                break;
                
            case 4:
                printf("Thank you!\n");
                break;
                
            default:
                printf("Invalid choice!\n");
        }
    } while (pick != 4);
    freeTree(root);

    return 0;
}
